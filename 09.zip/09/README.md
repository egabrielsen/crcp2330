## PONG

To play, move the paddle up and down and don't let the ball cross past the left of
your paddle. Every time you hit the ball back into play you recieve one point. If 
your score goes down to 0, its GAME OVER! 

Enjoy!
